# Happy Birthday! 🎂👇

A Pen created on CodePen.

Original URL: [https://codepen.io/jh3y/pen/BaobKOJ](https://codepen.io/jh3y/pen/BaobKOJ).

Made a "Happy Birthday" button for this week's "Making awesome things for awesome people!"

There's sound of course!

Built with GreenSock.

Enjoy! 😎

-----

Sounds courtesy of [freesound.org](https://freesound.org)

- [Blowing out candle](https://freesound.org/people/Reitanna/sounds/242867/#) by [Reitanna](https://freesound.org/people/Reitanna/)

- [Happy Birthday](https://freesound.org/people/Percy%20Duke/sounds/23270/#) by [Percy Duke](https://freesound.org/people/Percy%20Duke/)

- [Cheer](https://freesound.org/people/jayfrosting/sounds/333404/#) by [jayfrosting](https://freesound.org/people/jayfrosting/)

- [Pop](https://freesound.org/people/InspectorJ/sounds/411639/#) by [InspectorJ](https://freesound.org/people/jayfrosting/sounds/333404/#)

- [Match strike](https://freesound.org/people/JarredGibb/sounds/248236/#) by [JarredGibb](https://freesound.org/people/JarredGibb/)

- [Party Horn](https://freesound.org/people/TiesWijnen/sounds/460496/#) by [TiesWijnen](https://freesound.org/people/TiesWijnen/)